package com.nawaz.Java8;

public class Java8_Programs {
	
	/*
	 * How to get unique values from ArraList using Java8 How to find duplicate
	 * elements in a given integers list in Java using Stream Functions Count no of
	 * occurences of words in given String using Java8
	 */
	

}
