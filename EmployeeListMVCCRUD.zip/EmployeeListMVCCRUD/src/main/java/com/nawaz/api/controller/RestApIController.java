package com.nawaz.api.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nawaz.dao.EmployeeDAO;
import com.nawaz.model.Employee;
import com.nawaz.service.EmployeeService;

@RestController
public class RestApIController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private EmployeeDAO employeeDAO;

	@RequestMapping(value = "/restResp", method = RequestMethod.GET)
	public String broitsRest() {
		return "yes its rest response";

	}

	/*
	 * @RequestMapping(value = "/getAllEmployees", method = RequestMethod.GET)
	 * public ResponseEntity<Employee> listEmployee(ModelAndView model) throws
	 * IOException { List<Employee> listEmployee =
	 * employeeService.getAllEmployees();
	 * 
	 * model.addObject("listEmployee", listEmployee); model.setViewName("home");
	 * return model;
	 * 
	 * return new ResponseEntity<>(listEmployee, HttpStatus.OK); }
	 */

	@RequestMapping(value = "/employeesRest", method = RequestMethod.GET, 
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public List<Employee> getEmployees() {
		List<Employee> list = employeeDAO.getAllEmployees();
		return list;
	}
	
	@RequestMapping(value = "/employee/{empid}", method = RequestMethod.GET,
			  produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody 
	public Employee getEmployee(@PathVariable("empid") int empid) 
	{ 
		return employeeDAO.getEmployee(empid); 
	}
	
	@RequestMapping(value = "/addemployee",  method = RequestMethod.POST, 
		produces = { MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE }) 
	@ResponseBody 
	public String addEmployee(@RequestBody Employee emp) 
	{
		employeeDAO.addEmployee(emp);
		return "";
	}
	
	
	@RequestMapping(value = "/editemployee",  method = RequestMethod.PUT, 
			produces = { MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE }) 
	@ResponseBody 
	public String editEmployee(@RequestBody Employee emp) 
	{
		employeeDAO.updateEmployee(emp);
		return "";
	}
	
	@RequestMapping(value = "/employees/{empid}", method = RequestMethod.DELETE, 
		produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody 
	public String deleteEmployee(@PathVariable("empid") int empid)
	{ 
		employeeDAO.deleteEmployee(empid);
		return "";
	}

	// ########################################################################3

	/*
	 * 
	 * @RequestMapping("/")
	 * 
	 * @ResponseBody public String welcome() { return
	 * "Welcome to RestTemplate Example."; }
	 * 
	 * // URL: // http://localhost:8080/SpringMVCRESTful/employees //
	 * http://localhost:8080/SpringMVCRESTful/employees.xml //
	 * http://localhost:8080/SpringMVCRESTful/employees.json
	 * 
	 * @RequestMapping(value = "/employees", // method = RequestMethod.GET, //
	 * produces = { MediaType.APPLICATION_JSON_VALUE,
	 * MediaType.APPLICATION_XML_VALUE })
	 * 
	 * @ResponseBody public List<Employee> getEmployees() { List<Employee> list =
	 * employeeDAO.getAllEmployees(); return list; }
	 * 
	 * // URL: // http://localhost:8080/SpringMVCRESTful/employee/{empNo} //
	 * http://localhost:8080/SpringMVCRESTful/employee/{empNo}.xml //
	 * http://localhost:8080/SpringMVCRESTful/employee/{empNo}.json
	 * 
	 * @RequestMapping(value = "/employee/{empNo}", // method = RequestMethod.GET,
	 * // produces = { MediaType.APPLICATION_JSON_VALUE,
	 * MediaType.APPLICATION_XML_VALUE })
	 * 
	 * @ResponseBody public Employee getEmployee(@PathVariable("empNo") String
	 * empNo) { return employeeDAO.getEmployee(empNo); }
	 * 
	 * // URL: // http://localhost:8080/SpringMVCRESTful/employee //
	 * http://localhost:8080/SpringMVCRESTful/employee.xml //
	 * http://localhost:8080/SpringMVCRESTful/employee.json
	 * 
	 * @RequestMapping(value = "/employee", // method = RequestMethod.POST, //
	 * produces = { MediaType.APPLICATION_JSON_VALUE,
	 * MediaType.APPLICATION_XML_VALUE })
	 * 
	 * @ResponseBody public Employee addEmployee(@RequestBody Employee emp) {
	 * 
	 * return employeeDAO.addEmployee(emp);
	 * 
	 * }
	 * 
	 * // URL: // http://localhost:8080/SpringMVCRESTful/employee //
	 * http://localhost:8080/SpringMVCRESTful/employee.xml //
	 * http://localhost:8080/SpringMVCRESTful/employee.json
	 * 
	 * @RequestMapping(value = "/employee", // method = RequestMethod.PUT, //
	 * produces = { MediaType.APPLICATION_JSON_VALUE,
	 * MediaType.APPLICATION_XML_VALUE })
	 * 
	 * @ResponseBody public Employee updateEmployee(@RequestBody Employee emp) {
	 * 
	 * return employeeDAO.updateEmployee(emp); }
	 * 
	 * // URL: // http://localhost:8080/SpringMVCRESTful/employee/{empNo}
	 * 
	 * @RequestMapping(value = "/employees/{empNo}", // method =
	 * RequestMethod.DELETE, // produces = { MediaType.APPLICATION_JSON_VALUE,
	 * MediaType.APPLICATION_XML_VALUE })
	 * 
	 * @ResponseBody public void deleteEmployee(@PathVariable("empNo") String empNo)
	 * { employeeDAO.deleteEmployee(empNo); }
	 */

}
