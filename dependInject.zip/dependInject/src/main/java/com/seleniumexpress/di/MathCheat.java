package com.seleniumexpress.di;

public class MathCheat implements Cheat{

	@Override
	public void cheat() {
		System.out.println("Math cheaing started...");
		
	}

}
