package com.seleniumexpress.di;

public class ScienceCheat implements Cheat{

	@Override
	public void cheat() {
		System.out.println("Science cheaing started...");
		
	}

}
