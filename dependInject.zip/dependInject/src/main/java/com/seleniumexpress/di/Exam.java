package com.seleniumexpress.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Exam {

	public static void main(String[] args) {
		
		/*manually managing obj's
		 * Student student = new Student(); //student.studentName="Ravi";private ref of
		 * one class cannot be accessed by other class student.setStudentName("Raavi");
		 * student.displayStudentInfo();
		 */
		//setter Injection: till here spring creates object but to inject dependency declare in xml using property tag
		//where spring looks for the setter method of particular property declared and spring injects value to it.
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Student nawaz = context.getBean("studen", Student.class);
		nawaz.displayStudentInfo();
		
		Student dileep = context.getBean("dilip", Student.class);
		dileep.displayStudentInfo();
		/*
		 * Student ashis = context.getBean("ashish", Student.class);
		 * ashis.displayStudentInfo();
		 */
		
		//Constructor Injection

	}

}
