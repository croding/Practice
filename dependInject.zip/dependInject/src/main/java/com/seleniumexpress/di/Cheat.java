package com.seleniumexpress.di;

public interface Cheat {
	
	public void cheat(); 

}
