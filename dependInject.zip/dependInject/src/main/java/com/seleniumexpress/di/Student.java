package com.seleniumexpress.di;

/*Dependency Injection -- Injecting dependencies
 * Spring is going to inject values for your dependencies using Setter & Constructor Injection
 * 
 * 
 * 
 */
public class Student {

	/*If we have two classes to implement then use Interface Cheat for loose coupling
	 * private MathCheat mathcheat; 
	 */
	
	private Cheat cheat;
	
	public void setCheat(Cheat cheat) {
		this.cheat = cheat;
	}

	public void Cheating() 
	{
		 System.out.println("Cheating method called"); 
		 //scienceCheat.scienCheat();
		 cheat.cheat();
		 System.out.println("Student Id is : "+id); 
	}
	/*Loose coupling using interface and method execution is selected at run time
	 * 
	 * public void setScienceCheat(ScienceCheat scienceCheat) { this.scienceCheat =
	 * scienceCheat; }
	 */

	private int id;
	private String studentName;
	

	
	public void setId(int id) {
		this.id = id;
	}

	/*
	 * public void setMathcheat(MathCheat mathcheat) { this.mathcheat = mathcheat; }
	 */


	public Student() {
		super();
	}
	/*
	 * public void setId(int id) { this.id = id;
	 * System.out.println("Setter Method id called"); }
	 * 
	 * public void setStudentName(String studentName) { this.studentName =
	 * studentName; System.out.println("Setter Method name called"); }
	 */
	public Student(int id) {
		super();
		this.id = id;
	}
	//constructor -- to initialize non static variable of a class during the time of obj creation/initialization
	public Student(int id, String studentName) {
		super();
		this.id = id;
		this.studentName = studentName;
	}
	
	void displayStudentInfo()
	{
		System.out.println("student Id is : " + id +" and student name is : " +studentName);
	}


}
