package com.seleniumexpress.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
	
	public static void main(String args[]) {
		
		/*
		 * Student stud = new Student(); stud.Cheating();
		 */
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Student studmcheater = context.getBean("studmcheat", Student.class);
		studmcheater.Cheating();
		
		/*for class level depnedency injection add bean with class qualified name inside property tag
		 * <bean id="studmcheat" class="com.seleniumexpress.di.Student"> <property
		 * name="mathcheat"> <bean class="com.seleniumexpress.di.MathCheat"></bean>
		 * </property> </bean>
		 */
	}

}
