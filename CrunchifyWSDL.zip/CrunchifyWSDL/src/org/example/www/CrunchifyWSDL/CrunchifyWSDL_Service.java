/**
 * CrunchifyWSDL_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.example.www.CrunchifyWSDL;

public interface CrunchifyWSDL_Service extends javax.xml.rpc.Service {
    public java.lang.String getCrunchifyWSDLSOAPAddress();

    public org.example.www.CrunchifyWSDL.CrunchifyWSDL_PortType getCrunchifyWSDLSOAP() throws javax.xml.rpc.ServiceException;

    public org.example.www.CrunchifyWSDL.CrunchifyWSDL_PortType getCrunchifyWSDLSOAP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
