package com.nawaz.BookStore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nawaz.BookStore.entity.Book;
@Repository
public interface BookRepository extends JpaRepository<Book, Integer>{

}
