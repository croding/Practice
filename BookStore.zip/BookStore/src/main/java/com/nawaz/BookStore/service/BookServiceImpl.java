package com.nawaz.BookStore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nawaz.BookStore.entity.Book;
import com.nawaz.BookStore.repository.BookRepository;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepository repo;
	
	@Override
	public void save(Book b) {
		
		repo.save(b);

	}

	@Override
	public List<Book> getAllBooks() {
		
		return repo.findAll();
	}

}
