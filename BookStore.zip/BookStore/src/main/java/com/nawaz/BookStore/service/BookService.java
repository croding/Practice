package com.nawaz.BookStore.service;

import java.util.List;

import com.nawaz.BookStore.entity.Book;

public interface BookService {
	
	public void save(Book b);
	
	public List<Book> getAllBooks(); 

}
