package com.choudhury.domain;

import java.util.List;

public class BookList {

	private List<Book> data;

	public List<Book> getData() {
		return data;
	}

	public void setData(List<Book> data) {
		this.data = data;
	}
}