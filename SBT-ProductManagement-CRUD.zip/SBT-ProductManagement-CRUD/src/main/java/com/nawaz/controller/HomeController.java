package com.nawaz.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.nawaz.entity.Products;
import com.nawaz.repository.ProductRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {
	
	@Autowired
	private ProductRepository productRepo;
	
	@GetMapping("/")
	public String home(Model m) {
		
		List<Products> list = productRepo.findAll();
		m.addAttribute("all_products",list);
		
		return "index";
	}
	
	@GetMapping("/load_form")
	public String loadForm() {
		return "add";
	}
	
	@GetMapping("/edit_form{id}")
	public String editForm(@PathVariable(value="id") int id, Model m) {
		
		Optional<Products> product = productRepo.findById(id);
		
		Products pro = product.get();
		m.addAttribute("product	",pro);
		
		return "edit";
	}
	
	@PostMapping("/save_products")
	public String saveProducts(@ModelAttribute Products products, HttpSession session) {
		
		productRepo.save(products);
		session.setAttribute("msg", "Products Added Successfully");
		
		return "redirect:/load_form";
	}
	
	@PostMapping("/update_product")
	public String updateProduct(@ModelAttribute Products products, HttpSession session) {
		
		productRepo.save(products);
		session.setAttribute("msg", "Products Update Successfully");
		
		return "redirect:/";
	}
	
	@GetMapping("/delete/{id}")
	public String deleteProduct(@PathVariable(value="id") long id,HttpSession session) {
		
		productRepo.deleteById((int) id);
		session.setAttribute("msg", "Products Deleted Successfully");
		
		return "redirect:/";
	}

}
