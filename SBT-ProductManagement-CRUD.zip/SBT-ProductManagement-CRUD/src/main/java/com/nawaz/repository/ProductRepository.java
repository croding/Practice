package com.nawaz.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nawaz.entity.Products;

public interface ProductRepository extends JpaRepository<Products, Integer>{

}
