package com.springmvc.api;
	
	import java.util.List;
	 
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpHeaders;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.MediaType;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;
	import org.springframework.web.bind.annotation.RestController;
	import org.springframework.web.util.UriComponentsBuilder;

import com.springmvc.dao.EmpDao;
import com.springmvc.entity.Emp;
	 
	@RestController
	public class APIController {
	 
	    @Autowired
	    Emp emp;  //Service which will do all data retrieval/manipulation work
	 
	     
	    //-------------------Retrieve All Emps--------------------------------------------------------
	     
	    @RequestMapping(value = "/Emp/", method = RequestMethod.GET)
	    public ResponseEntity<List<Emp>> listAllEmps() {
/*	        List<EmpDao> Emps = emp.getAllEmp();
	        if(Emps.isEmpty()){
	            return new ResponseEntity<List<Emp>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
	        }
	        return new ResponseEntity<List<Emp>>(Emps, HttpStatus.OK);*/
	    	
	    	System.out.println("EMP API called");
			return null;
	    }
	 
	 
	/*
	 * //-------------------Retrieve Single
	 * Emp--------------------------------------------------------
	 * 
	 * @RequestMapping(value = "/Emp/{id}", method = RequestMethod.GET, produces =
	 * MediaType.APPLICATION_JSON_VALUE) public ResponseEntity<Emp>
	 * getEmp(@PathVariable("id") long id) {
	 * System.out.println("Fetching Emp with id " + id); Emp Emp = emp.findById(id);
	 * if (Emp == null) { System.out.println("Emp with id " + id + " not found");
	 * return new ResponseEntity<Emp>(HttpStatus.NOT_FOUND); } return new
	 * ResponseEntity<Emp>(Emp, HttpStatus.OK); }
	 * 
	 * 
	 * 
	 * //-------------------Create a
	 * Emp--------------------------------------------------------
	 * 
	 * @RequestMapping(value = "/Emp/", method = RequestMethod.POST) public
	 * ResponseEntity<Void> createEmp(@RequestBody Emp Emp, UriComponentsBuilder
	 * ucBuilder) { System.out.println("Creating Emp " + Emp.getName());
	 * 
	 * if (emp.isEmpExist(Emp)) { System.out.println("A Emp with name " +
	 * Emp.getName() + " already exist"); return new
	 * ResponseEntity<Void>(HttpStatus.CONFLICT); }
	 * 
	 * emp.saveEmp(Emp);
	 * 
	 * HttpHeaders headers = new HttpHeaders();
	 * headers.setLocation(ucBuilder.path("/Emp/{id}").buildAndExpand(Emp.getId()).
	 * toUri()); return new ResponseEntity<Void>(headers, HttpStatus.CREATED); }
	 * 
	 * 
	 * //------------------- Update a Emp
	 * --------------------------------------------------------
	 * 
	 * @RequestMapping(value = "/Emp/{id}", method = RequestMethod.PUT) public
	 * ResponseEntity<Emp> updateEmp(@PathVariable("id") long id, @RequestBody Emp
	 * Emp) { System.out.println("Updating Emp " + id);
	 * 
	 * Emp currentEmp = emp.findById(id);
	 * 
	 * if (currentEmp==null) { System.out.println("Emp with id " + id +
	 * " not found"); return new ResponseEntity<Emp>(HttpStatus.NOT_FOUND); }
	 * 
	 * currentEmp.setName(Emp.getName()); currentEmp.setAge(Emp.getAge());
	 * currentEmp.setSalary(Emp.getSalary());
	 * 
	 * emp.updateEmp(currentEmp); return new ResponseEntity<Emp>(currentEmp,
	 * HttpStatus.OK); }
	 * 
	 * //------------------- Delete a Emp
	 * --------------------------------------------------------
	 * 
	 * @RequestMapping(value = "/Emp/{id}", method = RequestMethod.DELETE) public
	 * ResponseEntity<Emp> deleteEmp(@PathVariable("id") long id) {
	 * System.out.println("Fetching & Deleting Emp with id " + id);
	 * 
	 * Emp Emp = emp.findById(id); if (Emp == null) {
	 * System.out.println("Unable to delete. Emp with id " + id + " not found");
	 * return new ResponseEntity<Emp>(HttpStatus.NOT_FOUND); }
	 * 
	 * emp.deleteEmpById(id); return new ResponseEntity<Emp>(HttpStatus.NO_CONTENT);
	 * }
	 * 
	 * 
	 * //------------------- Delete All Emps
	 * --------------------------------------------------------
	 * 
	 * @RequestMapping(value = "/Emp/", method = RequestMethod.DELETE) public
	 * ResponseEntity<Emp> deleteAllEmps() {
	 * System.out.println("Deleting All Emps");
	 * 
	 * emp.deleteAllEmps(); return new ResponseEntity<Emp>(HttpStatus.NO_CONTENT); }
	 * 
	 * }
	 */
	}

