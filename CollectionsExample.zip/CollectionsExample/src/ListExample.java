import java.util.ArrayList;
import java.util.List;

public class ListExample {

	public static void main(String[] args) {
		
		List<String> listarr = new ArrayList();
		
		List<Object> listObj = new ArrayList();
		
		listarr.add("Ravi");
		listarr.add("Pramod");
		listarr.add("Krupal");
		listarr.add("Kapil");
		listarr.add(0, "kumar");
		listarr.add("1");
		
		listObj.addAll(listarr);
		listObj.add(10);
		for(String s:listarr)
		{
		System.out.println("List of Array details : " +s);
		}
		for(Object s:listObj)
		{
		System.out.println("List of Array Objects : " +s);
		}
		
		String k[] = listarr.toArray(new String[listarr.size()]);
		for (String str : k) {
            System.out.println(str);
		}
	}

}
