package com.nawaz.autowired;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Human {
	@Autowired
	@Qualifier("Octpousheart")//if we want specific object to be picked by spring use qualifier annot
	private Heart heart;
	//creates human obj
	/*these are not needed if we use @Autowired and Qualifier as we are telling which obj to be used and here setter is not needed
	 * public Human() { } //this is replacement of autowire in xml, to enable this
	 * annotation add context-annotation-config //@Autowired should be before
	 * constructor or setter method(first checks byType then byName)
	 * 
	 * public Human(Heart heart) { this.heart = heart; } public void setHeart(Heart
	 * heart) { this.heart = heart; }
	 */
	
	public void startPumping() 
	{
		if(heart!=null)
		{
		heart.pump();
		System.out.println("Name of Animal is : " + heart.getNameOfAnimal() + " and "+ 
				"Num of Hearts is : " + heart.getNoOfHeart());
		}
		else {
			System.out.println("You are Dead...");
		}
	}
	
	
	
}
