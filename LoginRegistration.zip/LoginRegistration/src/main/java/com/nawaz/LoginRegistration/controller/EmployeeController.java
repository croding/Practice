package com.nawaz.LoginRegistration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nawaz.LoginRegistration.dto.EmployeeDto;
import com.nawaz.LoginRegistration.dto.LoginDto;
import com.nawaz.LoginRegistration.response.LoginResponse;
import com.nawaz.LoginRegistration.service.EmployeeService;

@RestController
@CrossOrigin
@RequestMapping("api/v1/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	@PostMapping(path="/save")
	public String saveEmployee(@RequestBody EmployeeDto empDto) {
		String id= service.addEmployee(empDto);
		return id;
	}
	//ResponseEntity to check whether password is success or not
	@PostMapping(path="/login")
	public ResponseEntity<?> loginEmployee(@RequestBody LoginDto loginDto) {
		LoginResponse loginResponse = service.loginEmployee(loginDto);
		return ResponseEntity.ok(loginResponse);
	}

}
