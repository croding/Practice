package com.nawaz.LoginRegistration.dto;

import jakarta.persistence.Column;

public class EmployeeDto {
	
	private int eid;
	
	private String employeename;
	
	private String email;
	
	private String password;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEmployeename() {
		return employeename;
	}

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public EmployeeDto(int eid, String employeename, String email, String password) {
		
		this.eid = eid;
		this.employeename = employeename;
		this.email = email;
		this.password = password;
	}

	public EmployeeDto() {
		
	}

	@Override
	public String toString() {
		return "EmployeeDto [eid=" + eid + ", employeename=" + employeename + ", email=" + email + ", password="
				+ password + "]";
	}
	
	

}
