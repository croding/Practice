package com.nawaz.LoginRegistration.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.nawaz.LoginRegistration.dto.EmployeeDto;
import com.nawaz.LoginRegistration.dto.LoginDto;
import com.nawaz.LoginRegistration.entity.Employee;
import com.nawaz.LoginRegistration.repository.EmployeeRepository;
import com.nawaz.LoginRegistration.response.LoginResponse;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeRepository repo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public String addEmployee(EmployeeDto empdto) {
		
		Employee employee = new Employee(
				
				empdto.getEid(),
				empdto.getEmployeename(),
				empdto.getEmail(),
				
				this.passwordEncoder.encode(empdto.getPassword())
				
				);
		
		repo.save(employee);
		
		return employee.getEmployeename();
	}

	@Override
	public LoginResponse loginEmployee(LoginDto loginDto) {
		
		String msg="";
		Employee employee = repo.findByEmail(loginDto.getEmail());
		if(employee!=null) {
			String password = loginDto.getPassword();
			String encodedPasword = employee.getPassword();
			Boolean isPwdRight = passwordEncoder.matches(password, encodedPasword);
			if(isPwdRight) {
				Optional<Employee> emp = repo.findOneByEmailAndPassword(loginDto.getEmail(), encodedPasword);
				if(emp.isPresent()) {
					return new LoginResponse("Login Success", true);
				}else {
					return new LoginResponse("Login Failed", false);
				}
			}else {
				return new LoginResponse("password doesn't match", false);
			}
		}else {
			return new LoginResponse("Email doesn't exists", false);
		}
		
	}

}
