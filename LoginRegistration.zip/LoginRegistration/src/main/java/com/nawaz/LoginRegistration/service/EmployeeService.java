package com.nawaz.LoginRegistration.service;

import com.nawaz.LoginRegistration.dto.EmployeeDto;
import com.nawaz.LoginRegistration.dto.LoginDto;
import com.nawaz.LoginRegistration.response.LoginResponse;

public interface EmployeeService {
	
	String addEmployee(EmployeeDto empdto);
	
	LoginResponse loginEmployee(LoginDto loginDto);

}
