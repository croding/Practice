package com.nawaz.LoginRegistration.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	
	@Id
	@Column(name="employee_Id",length=45)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int eid;
	@Column(name="employee_name",length=255)
	private String employeename;
	@Column(name="email",length=255)
	private String email;
	@Column(name="password",length=255)
	private String password;
	
	public Employee(int eid, String employeename, String email, String password) {
		
		this.eid = eid;
		this.employeename = employeename;
		this.email = email;
		this.password = password;
	}
	public Employee() {
		
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEmployeename() {
		return employeename;
	}
	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", employeename=" + employeename + ", email=" + email + ", password=" + password
				+ "]";
	}
	
	

}
