package com.seleniumexpress.di;

/*Dependency Injection -- Injecting dependencies
 * Spring is going to inject values for your dependencies using Setter & Constructor Injection
 * 
 * 
 * 
 */
public class Student {

	private String studentName;
	
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	void displayStudentInfo()
	{
		System.out.println("student name is : " +studentName);
	}
}
