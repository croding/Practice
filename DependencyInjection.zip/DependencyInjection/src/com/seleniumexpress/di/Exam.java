package com.seleniumexpress.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Exam {

	public static void main(String[] args) {
		
		/*manually managing obj's
		 * Student student = new Student(); //student.studentName="Ravi";private ref of
		 * one class cannot be accessed by other class student.setStudentName("Raavi");
		 * student.displayStudentInfo();
		 */
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		

	}

}
