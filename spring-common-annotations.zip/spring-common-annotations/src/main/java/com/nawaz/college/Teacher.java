package com.nawaz.college;

public interface Teacher {
	
	public void teach();

}
