package com.nawaz.college;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Component("collegeBean")removing as per the alternative @Bean
@Component//if bean id isnot mentioned then it takes class name with lower case in context
public class College {
	
	@Value("${college.name}")
	private String collegeName;
	
	@Required
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	@Autowired//for creating obj we added @component and to inject we need @Autowired
	@Qualifier("mathTeacher")//first letter should be small and without this annot we 
	//can use @primary on implemented class. But in both @Qualifier executes first
	private Teacher teacher;
	
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	
	@Autowired
	private Principal principal;
	/*commented to do setter injection of principal
	 * public College(Principal principal) { this.principal = principal; }
	 */

	public void setPrincipal(Principal principal) {
		this.principal = principal;
		System.out.println("using Setter Injection to create obj");
	}

	public void test()
	{
		principal.principalInfo();
		teacher.teach();
		System.out.println("My College Name is : " +collegeName);
		System.out.println("testing college class method");
	}
	

}
