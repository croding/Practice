package com.nawaz.college;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/*bean xml way
 * <context:component-scan base-package="com.nawaz.college"></context:component-scan>
<!-- we can configure same in java using @component<bean id = "collegeBean" class="com.nawaz.college.College"></bean> 
	and to enable this annotation add <context:component-scan base-package="com.nawaz.college"> in beans.xml or from java end as well @componentScan by creating configuration class-->
*/

@Configuration
//@ComponentScan(basePackages = "com.nawaz.college")removing as per the alternative @Bean
@ComponentScan(basePackages = "com.nawaz.college")
@PropertySource("classpath:college-info.properties")//to display values from property file same as we do in xml way
public class CollegeConfig {
	
	/*commented out to do it in other way using @component&@componentscan
	 * //creating obj of college class where id is method here
	 * 
	 * @Bean public Teacher mathTeacherBean() { return new MathTeacher(); }
	 * 
	 * @Bean public Principal principalBean() { return new Principal(); }
	 * 
	 * @Bean(name={"colBean", "collegeBeanAnother"}) public College
	 * collegeBean()//collegeBean is bean id { //College college = new
	 * College(principalBean());//constructor injection of principalbean College
	 * college = new College(); college.setPrincipal(principalBean());
	 * college.setTeacher(mathTeacherBean()); return college; }
	 */
	
	

}
