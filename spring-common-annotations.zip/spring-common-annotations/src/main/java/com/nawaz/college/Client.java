package com.nawaz.college;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		
		//ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		ApplicationContext context = new AnnotationConfigApplicationContext(CollegeConfig.class);
		System.out.println("Beans.xml loaded..");
		//College college = context.getBean("collegeBean", College.class);
		//College college = context.getBean("collegeBeanAnother", College.class);@Bean related
		College college = context.getBean("college", College.class);
		System.out.println("College Obj created by spring" +college);
		college.test();
		((AnnotationConfigApplicationContext)context).close();//rather taking interface reference 
		//Application Context above take class reference(Annotation..) to get close() without casting 
	}

}
