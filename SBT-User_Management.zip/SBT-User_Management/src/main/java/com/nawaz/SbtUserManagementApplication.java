package com.nawaz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbtUserManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbtUserManagementApplication.class, args);
	}

}
