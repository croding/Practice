package com.nawaz.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.nawaz.entity.UserDtls;
import com.nawaz.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {
	
	@Autowired
	private UserService service;
	
	@GetMapping("/")
	public String index() {
		
		return "index";
	}
	
	@GetMapping("/signin")
	public String login() {
		
		return "login";
	}
	
	@GetMapping("/register")
	public String register() {
		
		return "register";
	}
	
	@PostMapping("/createuser")
	public String createUser(@ModelAttribute UserDtls user, HttpSession session) {
		
		//System.out.println(user);
		
		boolean f = service.checkEmail(user.getEmail());
		
		if(f)
		{
			//System.out.println("Email Id already exists");
			session.setAttribute("msg", "Email Id Already Exists");
		} else {
			
			UserDtls userdetails = service.createUser(user);
			if(userdetails !=null) {
				session.setAttribute("msg", "Registered Successfully");
			} else {
				session.setAttribute("msg", "Something Wrong on Server");
			}	
			
		}
		
		
		return "redirect:/register";
	}

}
