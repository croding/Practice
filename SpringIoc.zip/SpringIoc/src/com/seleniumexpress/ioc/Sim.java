package com.seleniumexpress.ioc;

public interface Sim {
	
	public void calling();
	public void data();

}
