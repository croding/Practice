package com.seleniumexpress.ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Mobile {

	public static void main(String[] args) {
		
		/*
		 * Airtel airtel = new Airtel(); airtel.calling(); airtel.data();
		 */
		
		/* Vodafone voda = new Vodafone(); voda.calling(); voda.data(); */
		
		/*Configure this ref and obj without touching code using spring framework(spring container- creates and manages obj's)
		 * Sim simobj = new Vodafone(); simobj.calling(); simobj.data();
		 *Spring says, to mention all the classes in config xml file in <beans/> and its container-IOC container reads those classes and creates objects(bean)
		 *and access those beans using getBean("a").
		 *Types of IOC Container:1)BeanFactory 2)ApplicationContext <== These are interfaces
		 *To imlement them we have classes.
		 *ApplicationContext==>ClassPathXmlApplicationContext
		 */
		
		/*Spring IOC takes care of creating the objects
		 * ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		 * System.out.println("Config loaded"); //class level model Vodafone voda =
		 * context.getBean("vodaphone", Vodafone.class); voda.calling(); voda.data()
		 * 
		 * //Interface model without updating class name update in config.xml id to sim
		 * and update class to the one we want to run Sim sim = context.getBean("sim",
		 * Sim.class); sim.calling(); sim.data();
		 *To inject objects to respective classes we use Dependency Injection
		 */
		
	}

}
