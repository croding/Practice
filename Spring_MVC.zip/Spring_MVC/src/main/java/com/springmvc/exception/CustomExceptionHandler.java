package com.springmvc.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice//to use exceptions globally
public class CustomExceptionHandler {
	
	@ExceptionHandler(NumberFormatException.class)
	public String numberException()
	{
		return "error";
	}
	
	@ExceptionHandler(NullPointerException.class)
	public String nullException()
	{
		return "error";
	}
	
	@ExceptionHandler(Exception.class)
	public String allException()
	{
		return "error";
	}

}
