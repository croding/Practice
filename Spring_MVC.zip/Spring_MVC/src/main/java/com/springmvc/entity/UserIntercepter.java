package com.springmvc.entity;

public class UserIntercepter {
	
	private String name;

	public UserIntercepter(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	

}
