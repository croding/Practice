package com.springmvc.service;

import com.springmvc.entity.User;

public interface UserService {
	
	public int registerUser(User user);

}
