package com.springmvc.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springmvc.entity.UserIntercepter;

@Controller
public class InterceptingController {

	@RequestMapping("/intercepthome")
	public String home()
	{
		return "homeIntercept";
	}
	
	@RequestMapping("/loginwithintercept")
	public String login(HttpSession session)
	{
		session.setAttribute("loginUser", new UserIntercepter("nawaz"));
		return "homeIntercept";
	}
}
