package com.springmvc.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.springmvc.entity.User;
import com.springmvc.service.UserService;

@Controller
public class HomeController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping("/home")
	public String Home(Model m)
	{
		m.addAttribute("name", "Nawaz");
		m.addAttribute("rollno", 101);
		
		//Integer.parseInt("TestMsg");
		
		List<String> list = new ArrayList<>();
		list.add("Mahesh");
		list.add("Ravi");
		list.add("prabhas");
		
		m.addAttribute("list", list);
		
		return "home";
	}
	
	/*commented as we created class to it
	 * @ExceptionHandler(NumberFormatException.class) public String
	 * numberException() { return "error"; }
	 * 
	 * @ExceptionHandler(NullPointerException.class) public String nullException() {
	 * return "error"; }
	 * 
	 * @ExceptionHandler(Exception.class) public String allException() { return
	 * "error"; }
	 */
	
	@RequestMapping(path="/login")
	//public String login()
	public ModelAndView login()
	{
		ModelAndView model = new ModelAndView();
		model.addObject("session", "Session I");
		model.addObject("regnuber", 123456);
		List<String> list = new ArrayList<>();
		list.add("Sachin");
		list.add("Dhoni");
		list.add("Rohit");
		list.add("Virat");
		model.addObject("list", list);
		//to show view
		model.setViewName("loginpage");
		//return "loginpage";
		return model;
	}
	@RequestMapping(path="/register", method=RequestMethod.GET)
	public String register()
	{
		return "register";
	}
	//if we want to fetch all user data from view use @modelAttribute
	@RequestMapping(path="/createUser", method = RequestMethod.POST)
	public String registerUser(@ModelAttribute User user, @RequestParam("img") String img, Model m)
	{
		System.out.println("Image Name : "+img);
		System.out.println("Create User Registration Method : " +user);
		
		user.setImage(img);
		userService.registerUser(user);
		
		//m.addAttribute("msg", "Registrated Successfully..!");
		m.addAttribute("user", user);
		
		//return "redirect:/register";//redirected or else when empty form is resubmitted again
		//previous data is been added again.
		
		return "success";
	}
	@RequestMapping(path="/google")
	public String redirectPage()
	{
		return "redirect:http://www.google.com";
		
	}
	@RequestMapping(path="/yahoo")
	public RedirectView redirect2ndway()
	{
		RedirectView redirect = new RedirectView();
		redirect.setUrl("https://in.search.yahoo.com/");
		return redirect;
	}
	
	@RequestMapping(path="/search", method = RequestMethod.POST)
	public String searche(@RequestParam("keyword") String keyword)
	{
		String url="http://www.google.com/search?q="+keyword;
		return "redirect:"+url;
	}
	
	@RequestMapping(path="/user/{id}")
	public String demo(@PathVariable("id") int id)
	{
		System.out.println("id = "+id);
		return "home";
	}
	
	@RequestMapping(path="/file_upload")
	public String fileUploadPage()
	{
		return "file_upload";
	}
	
	@RequestMapping(path="/fileUpload", method = RequestMethod.POST)
	public String fileUpload(@RequestParam("img") CommonsMultipartFile file, HttpServletRequest request, Model m)
	{
	
		System.out.println(file.getName());
		System.out.println(file.getSize());
		System.out.println(file.getContentType());
		System.out.println(file.getOriginalFilename());
		
		byte[] bytes = file.getBytes();
		
		String path = request.getServletContext().getRealPath("/")+
				"WEB-INF"+File.separator+"resources"+File.separator+"img"
				+File.separator+file.getOriginalFilename();
		System.out.println("path to be saved : " +path);
		
		try {
			FileOutputStream fos = new FileOutputStream(path);
			fos.write(bytes);
			fos.close();
			System.out.println("File Uploaded successfully");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		m.addAttribute("imgname", file.getOriginalFilename());
		
		return "file_success";
	}
	
}
