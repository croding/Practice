package com.practice;


	
	enum Laptop{
		HP(2000), MAC(2500), LENOVO, DELL(800);
		private int price;
		
		private Laptop() {
			price = 1500;
		}

		private Laptop(int price) {
			this.price = price;
		}

		public int getPrice() {
			return price;
		}

		public void setPrice(int price) {
			this.price = price;
		}
			
	}
		
	public class EnumExample {
		public static void main(String args[]) {
			for(Laptop lap : Laptop.values())
			{
				System.out.println(lap + ":" + lap.getPrice());
			}
		}
	}


