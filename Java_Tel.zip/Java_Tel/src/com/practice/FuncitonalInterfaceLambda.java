package com.practice;

@FunctionalInterface
interface A
{
	//void show(int i);
	int add(int a, int  b);
}

public class FuncitonalInterfaceLambda {

	public static void main(String[] args) {
		
		//A obj = (i) -> System.out.println("Value to be printed is : " +i);
		//obj.show(5);
		A obj = (a,b) -> (a+b);
		System.out.println("adding of two values : " +obj.add(5, 4));
		

	}

}
