public class Main {
    public static void main(String[] args) {

        int a = 1;
        String name = "Ravi";

        int rollno[] = (10,20,30,69,70);

        System.out.println("Hello world!");
    }
}