package ArrayListConcept;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;

public class GenericArrayList {

	public static void main(String[] args) {

		ArrayList<Integer> markList = new ArrayList<>();
		
		markList.add(10);
		
		ArrayList<String> studentList = new ArrayList<>();
		studentList.add("tom");
		studentList.add("Nawaz");
		studentList.add("srinu");
		studentList.add("Jack");
		
		System.out.println("Using Typical For Loop");
		for(int i=0; i<studentList.size(); i++) {
			
			System.out.println("Student List: " +studentList.get(i));
		}
		
		System.out.println("Using ForEach Loop");
		for(String s:studentList) {
			System.out.println("Student List: "+s);
		}
		
		System.out.println("Using Iterator");
		Iterator<String> it = studentList.iterator();
		while(it.hasNext()) {
			System.out.println("Student List: "+it.next());
		}
		
		System.out.println("Using Java8 Lambda func");
		studentList.stream().forEach(result ->System.out.println("Student List: "+result));
		
		System.out.println("List with Other Collections::::");
		ArrayList<Integer> numbers= new ArrayList<>(Arrays.asList(10,20,40,60));	
		System.out.println("Numbers added" +numbers);
		
		System.out.println("Comparing two Array Lists <---->");
		ArrayList<String> ar1 = new ArrayList<>(Arrays.asList("Java", "Python","Salesforce", "Linux","Java"));
		
		ArrayList<String> ar2 = new ArrayList<>(Arrays.asList("DevOps", "testing"));
		
		ar1.addAll(1,ar2);
		System.out.println(ar1);
		
		
		ArrayList<Object> cloneList = new ArrayList<>(ar1);
		System.out.println(cloneList);
		
		System.out.println("Index of Java:" +ar1.lastIndexOf("Java") );
		System.out.println("Remove if number is divisible by 3 : " +numbers.removeIf(result->result%3 == 0));
		System.out.println(numbers);
		System.out.println("Retain specific values : "+ ar1.retainAll(Collections.singleton("Java")));
		System.out.println("Retained Values" + ar1);
		
		System.out.println("--> ArrayList to Array <----");
		ArrayList<String> newArrayList = new ArrayList<>(Arrays.asList("Java", "Python","Salesforce", "Linux","Java"));
		Object[] arr = newArrayList.toArray();
		System.out.println("ArrayList after converting to Array : " +Arrays.toString(arr));
		
		for(Object o:arr) {
			System.out.println(o);
		}
	}

}
