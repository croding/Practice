package ArrayListConcept;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		
		ArrayList<Object> ar = new ArrayList<>();
		ar.add(10);
		ar.add(0.2);
		ar.add("testing");
		ar.add(true);
		
		System.out.println(ar);
		System.out.println("Size of Array List: "+ar.size());
		
		System.out.println("Value at Index 2:"+ar.get(2));
		
		

	}

}
