package ArrayListConcept;

import java.util.ArrayList;
//By default virtual capacity of Array List is 10 but physical capacity is o
public class VirtualCapacityOfArrayList {

	public static void main(String[] args) {

		ArrayList<Object> ar = new ArrayList<>();
		
		System.out.println(ar.size());

	}

}
