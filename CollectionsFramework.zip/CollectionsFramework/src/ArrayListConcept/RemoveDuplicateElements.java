package ArrayListConcept;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveDuplicateElements {

	public static void main(String[] args) {
		
		ArrayList<Integer> arr = new ArrayList<>(Arrays.asList(1,2,3,4,4,2,5,5,6,6,7,3,2,10));
		
		//1.Linked Hashset
		LinkedHashSet<Integer> lnkdHashSet = new LinkedHashSet<>(arr);
		ArrayList<Integer> arr1 = new ArrayList<>(lnkdHashSet);
		System.out.println("After removing Duplicate elements : " +arr1);
		
	
		//2.Using Streams in Java8
		List<Integer> uniqueValues = arr.stream().distinct().collect(Collectors.toList());
		System.out.println("Unique Values using streams : "+uniqueValues);
	}
}
