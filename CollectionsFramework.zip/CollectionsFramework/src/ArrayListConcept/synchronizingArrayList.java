package ArrayListConcept;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


public class synchronizingArrayList {

	public static void main(String[] args) {
		//1.using Collections.synchronizedList()
		List<String> namesList = Collections.synchronizedList(new ArrayList<String>());
		namesList.add("Java");
		namesList.add("Ruby");
		namesList.add("Python");
		//to fetch/traverse values we need explicit synchronization
		synchronized(namesList) {
			Iterator<String> it = namesList.iterator();
			
			while(it.hasNext()) {
				System.out.println(it.next());
			}
		}
		
		//2.copyOnWriteArrayList
		System.out.println("Using CopyOnWriteArrayList : ");
		CopyOnWriteArrayList<String> empList = new CopyOnWriteArrayList<String>();
		empList.add("Tom");
		empList.add("Bob");
		empList.add("Teppo");
		
		Iterator<String> it = empList.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		
	}

}
