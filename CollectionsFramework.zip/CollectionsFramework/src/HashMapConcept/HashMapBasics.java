package HashMapConcept;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class HashMapBasics {

	public static void main(String[] args) {
		
		//no Ordering 
		//Stores Values  -- Key-Values Pair
		//Key cannot be duplicate
		//can store n no of null values but only one null key
		//not thread safe but to make it use concurrentHashMap
		HashMap<String,String> countries = new HashMap<>();
		countries.put("India", "New Delhi");
		countries.put("USA", "Washington DC");
		countries.put("UK", "London");
		countries.put("France", "null");
		countries.put("sweden", "null");
		countries.put("null", "Berlin");
		countries.put("null", "LA");
		//even if it has it replaces atest value with existing
		//countries.put("UK", "xyz");
		
		System.out.println(countries);
		System.out.println(countries.get("UK"));
		
		//Iterator over the keys by using keyset()
		Iterator<String> it = countries.keySet().iterator();
		
		while(it.hasNext()) {
			String key = it.next();
			String value = countries.get(key);
			System.out.println("key = " +key + " : " + "Value = " + value);
		}
		
		//Iterator over the set(pair): by using entryset()
		//entire set gets stores using entry class in HashMap
		Iterator<Entry<String,String>> itr1 = countries.entrySet().iterator();
		while(itr1.hasNext()) {
			Entry<String,String> entry = itr1.next();
			System.out.println("Key is : "+entry.getKey() + " and Value is = "+entry.getValue());
		}
		
		//Iterate HashMap using forEach and Lambda
		countries.forEach((k,v)->System.out.println("Key is : "+k +" and value =" +v));

	}

}
