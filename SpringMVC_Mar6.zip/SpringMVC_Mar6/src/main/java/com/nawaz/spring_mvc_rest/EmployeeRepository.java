package com.nawaz.spring_mvc_rest;


public interface EmployeeRepository extends CrudRepository<Employee, String>{

}
