package com.nawaz.employeeapp;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.nawaz.employeeapp.repo.EmployeeRepo;

@Configuration
public class EmployeeAppconfig {
	
	@Bean
	public EmployeeRepo employeeRepo() {
		 
		return new EmployeeRepo();
	}

}
