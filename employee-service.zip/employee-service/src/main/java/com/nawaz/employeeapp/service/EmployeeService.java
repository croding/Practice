package com.nawaz.employeeapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.nawaz.employeeapp.entity.Employee;
import com.nawaz.employeeapp.repo.EmployeeRepo;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepo employeeRepo;
	
	public Employee getEmployeeId(int id){
		
		//db call to fetch data
		Employee employee = employeeRepo.findById(id).get();
		
		return employee;
		
	}

}
