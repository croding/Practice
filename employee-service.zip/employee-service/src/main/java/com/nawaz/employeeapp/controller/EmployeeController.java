package com.nawaz.employeeapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.nawaz.employeeapp.entity.Employee;
import com.nawaz.employeeapp.repo.EmployeeRepo;
import com.nawaz.employeeapp.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/employees/{id}")
	public Employee getEmployeeDetails(@PathVariable("id") int id){
		
		//db call to fetch data
		Employee employee = employeeService.getEmployeeId(id);
		
		return employee;
		
	}

}
