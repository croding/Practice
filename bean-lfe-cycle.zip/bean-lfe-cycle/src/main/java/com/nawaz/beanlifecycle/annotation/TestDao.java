package com.nawaz.beanlifecycle.annotation;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//while execute if we get his exceptionException in thread "main" java.lang.ClassNotFoundException: org.postgresql.Driver
//add driver to classpath
public class TestDao {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		/*creating object IOC Container
		 * StudentDao dao = new StudentDao(); dao.selectAllRow();
		 * dao.deleteStudentRecord(102);
		 */
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		StudentDao sdao = context.getBean("studentDao", StudentDao.class);
		//sdao.deleteStudentRecord(103);
		sdao.selectAllRow();
		

	}

}
