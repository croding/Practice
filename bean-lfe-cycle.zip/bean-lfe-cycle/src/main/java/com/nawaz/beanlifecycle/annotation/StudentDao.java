package com.nawaz.beanlifecycle.annotation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import javax.annotation.*;

public class StudentDao {
	
	private String driver;
	private String url;
	private String userName;
	private String password;
	
	Connection con;
	Statement stmt;
	
	public void setDriver(String driver) {
		this.driver = driver;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	//below is init() method
	//@PostConstruct//used bcz we are getting null_pointer_exception for con
	public void init() throws ClassNotFoundException, SQLException
	{
		studentDBConnection();
	}
	//@PostConstruct//here we are telling spring once obj got created run this method.
	public void studentDBConnection() throws ClassNotFoundException, SQLException
	{
		//load driver
		Class.forName(driver);
		//get Connection
		con = DriverManager.getConnection(url, userName, password);
				
	}
	public void selectAllRow() throws ClassNotFoundException, SQLException
	{
		System.out.println("Retrieving data from DB...");
		studentDBConnection();
		//executequery
		stmt = con.createStatement();
		//String query = "Create Table Test(id int primary key,name varchar, address text)";
		/*stmt.executeUpdate(query);
		 * String query = "INSERT INTO Test (id,name,address) " + "VALUES " +
		 * "(101, "Nawaz", Hyd)";
		 */
		/*
		 * PreparedStatement st =
		 * con.prepareStatement("INSERT INTO Test (ID, NAME, ADDRESS) VALUES (?, ?, ?)"
		 * ); st.setInt(1, 105); st.setString(2, "Venky"); st.setString(3, "Sweden");
		 * st.executeUpdate();
		 */
		ResultSet rs = stmt.executeQuery("select * from Test");
		
		while(rs.next())
		{
			int studentId = rs.getInt(1);
			String studentName = rs.getString(2);
			String studentAddress = rs.getString(3);
			
			System.out.println(studentId + " " +studentName + " " + studentAddress);
		}
		
		System.out.println("Values inserted");
		stmt.close();
		con.close();
	}
	public void deleteStudentRecord(int studentId) throws ClassNotFoundException, SQLException
	{
		//executequery
		stmt = con.createStatement();
		
		stmt.executeUpdate("delete from Test where id=" +studentId);
		System.out.println("Record deleted with studentId" +studentId);
	}
	//@PreDestroy //commented to do same in xml way
	public void destroy() throws SQLException
	{
		closeDBConnection();
	}
	public void closeDBConnection() throws SQLException
	{
		stmt.close();
		con.close();
	}

}
