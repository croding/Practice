package com.home.mycafe.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller//when ever spring does component scan this class gets registered as controller
public class MyCafeControllers {
	@RequestMapping(path = "/cafe", method = RequestMethod.GET)
	public String showWelcomePage() 
	{
		return "welcome-page";
		
	}

}
