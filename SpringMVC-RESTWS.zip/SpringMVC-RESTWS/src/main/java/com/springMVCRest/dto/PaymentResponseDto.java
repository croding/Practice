package com.springMVCRest.dto;

import java.util.List;

import com.springMVCRest.model.Payment;

public class PaymentResponseDto {
	
	private String status;
	private String message;
	private String txDate;
	private List<Payment> paymentlist;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getTxDate() {
		return txDate;
	}
	public void setTxDate(String txDate) {
		this.txDate = txDate;
	}
	public List<Payment> getPaymentlist() {
		return paymentlist;
	}
	public void setPaymentlist(List<Payment> paymentlist) {
		this.paymentlist = paymentlist;
	}
	
	

}
