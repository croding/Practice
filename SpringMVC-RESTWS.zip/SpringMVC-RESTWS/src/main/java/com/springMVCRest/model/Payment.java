package com.springMVCRest.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Payment_Table")
public class Payment implements Serializable{
	@Id
	@GeneratedValue
	private int id;
	private String transactionId;
	private String vendor;
	private Date payDate;
	private Double amount;
	
	public Payment() {
		super();
	}
	
	public Payment(int id, String transactionId, String vendor, Date payDate, Double amount) {
		super();
		this.id = id;
		this.transactionId = transactionId;
		this.vendor = vendor;
		this.payDate = payDate;
		this.amount = amount;
	}
	
	public Payment(String transactionId, String vendor, Date payDate, Double amount) {
		super();
		this.transactionId = transactionId;
		this.vendor = vendor;
		this.payDate = payDate;
		this.amount = amount;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public Date getPayDate() {
		return payDate;
	}
	public void setPayDate(Date payDate) {
		this.payDate = payDate;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	

}
