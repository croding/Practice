package com.springMVCRest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springMVCRest.dto.PaymentResponseDto;
import com.springMVCRest.model.Payment;
import com.springMVCRest.service.PaymentService;

@RestController
@RequestMapping("paymentService")
public class PaymentController {
	@Autowired  
	private PaymentService service;
	
	//passing json payment obj from postman
	@PostMapping("/payNow")
	public PaymentResponseDto payInstant(@RequestBody Payment payment) {
		return service.pay(payment);
	}
	
	@GetMapping("/getVendorTransactions/{vendor}")
	public PaymentResponseDto getTransaction(@PathVariable String vendor) {
		return service.getTx(vendor);
	}
}
