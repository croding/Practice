package com.springMVCRest.service;

import com.springMVCRest.dto.PaymentResponseDto;
import com.springMVCRest.model.Payment;

public interface PaymentService {
	
	public PaymentResponseDto pay(Payment payment);
	public PaymentResponseDto getTx(String vendor);

}
