package com.springMVCRest.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.springMVCRest.dao.PaymentDao;
import com.springMVCRest.dto.PaymentResponseDto;
import com.springMVCRest.model.Payment;

@Service
@Transactional
public class PaymentServiceImpl implements PaymentService{
	
	private PaymentDao dao;//to achieve runtime polymorphism we are using Dao interface than implentation class
	PaymentResponseDto response = new PaymentResponseDto();
	@Override
	public PaymentResponseDto pay(Payment payment) {
		
		payment.setPayDate(new Date());
		String msg = dao.payNow(payment);//dao layer message
		
		response.setStatus(msg);
		//date we are setting from current date so we dont need to set in postman req,
		//so just manually add current date
		response.setTxDate(new SimpleDateFormat("dd/mm/yyyy HH:mm:ss a").format(new Date()));//converting date to string format
		return response;
	}

	@Override
	public PaymentResponseDto getTx(String vendor) {
		List<Payment> payments = dao.getTransactionInfo(vendor);
		response.setStatus("success");
		response.setPaymentlist(payments);
		return response;
	}

	
	
}
