package com.springMVCRest.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springMVCRest.model.Payment;
//persistance logic annotation
@Repository
public class PaymentDaoImpl implements PaymentDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public String payNow(Payment payment) {
		getSession().save(payment);
		return "Payment successful with amount : "+payment.getAmount() +"with transaction Id : "+payment.getTransactionId();
	}

	private Session getSession() {
		
		Session session = null;
		try {
			session=sessionFactory.getCurrentSession();
		}catch(HibernateException e) {
			session=sessionFactory.openSession();
		}
		return session;
		
	}

	@Override
	public List<Payment> getTransactionInfo(String vendor) {
		
		return getSession().createCriteria(Payment.class).add(Restrictions.eq("vendor", vendor)).list();
		
	}
}
