package com.springMVCRest.dao;

import java.util.List;

import com.springMVCRest.model.Payment;

public interface PaymentDao {
	
	String payNow(Payment payment);//bydefault all methods are public in interface
	public List<Payment> getTransactionInfo(String vendor);
}
