package com.servlet;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("/upload")
@MultipartConfig
public class UploadFile extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		Part p = req.getPart("files");
		String fileName=p.getSubmittedFileName();
		
		String description = req.getParameter("description");
		
		HttpSession session = req.getSession();
		
		System.out.println("File Name : "+fileName+" and Description is "+description);
		
		
		try {
			Connection conn = DBConnect.getConn();
			
			String sql = "insert into image_table(img_name, description) values(?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, fileName);
			ps.setString(2, description);
			
			int i = ps.executeUpdate();
			
			if(i==1)
			{
				String path = getServletContext().getRealPath("")+"imgs";
				System.out.println("Storage Path : "+path);
				
				File file = new File(path);
				
				p.write(path+File.separator+fileName);
				
				System.out.println("Upload Success");
				
				session.setAttribute("msg", "upload success");
				
				resp.sendRedirect("index.jsp");
				
			}else {
				System.out.println("Upload Error");
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

	
}
