package org.arpit.java2blog.controller;
import org.arpit.java2blog.bean.Country;
public class RequestWithType {

	public RequestWithType(Country country) {
		// TODO Auto-generated constructor stub
	}

	public String fetchReq(Country country) {

		String reqtyp = country.getRequestType();
		String returnVal;
		switch(reqtyp) {
		  case "A":
			  System.out.println("request type A is called");
			  returnVal = "request type A is called";
		    break;
		  case "B":
			  System.out.println("request type B is called");
			  returnVal = "request type B is called";
		    break;
		  case "C":
			  System.out.println("request type C is called");
			  returnVal = "request type C is called";
		  case "D":
			  System.out.println("request type D is called");
			  returnVal = "request type D is called";
	      default:
	    	  System.out.println("Un Identified Request Type");
	    	  returnVal = "request type fff is called";
	
		}
		return returnVal;

		
	}

}
