package org.arpit.java2blog.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "country")
public class Country {

	private int id;
	private String countryName;
	private String requestType;

	@XmlElement
	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public Country() {
		System.out.println("Default Constructor is called here:");
	}

	
	public Country(int id, String countryName, String requestType) {
		super();
		this.id = id;
		this.countryName = countryName;
		this.requestType = requestType;
	}

	@XmlElement
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@XmlElement
	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
}