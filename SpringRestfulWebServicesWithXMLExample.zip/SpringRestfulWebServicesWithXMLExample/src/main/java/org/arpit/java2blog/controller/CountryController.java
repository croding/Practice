package org.arpit.java2blog.controller;
import org.arpit.java2blog.controller.RequestWithType;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.arpit.java2blog.bean.Country;
import org.arpit.java2blog.bean.CountryList;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CountryController {
	
	@RequestMapping(value = "/countries", method = RequestMethod.GET)//,headers="Accept=application/xml")
	public CountryList getCountries()
	{
		CountryList countryList=createCountryList();
		return countryList;
	}

//	@RequestMapping(value = "/country/{id}", method = RequestMethod.GET)
//	public Country getCountryById(@PathVariable int id)
//	{
//		List<Country> listOfCountries = new ArrayList<Country>();
//		CountryList countryList=createCountryList();
//		listOfCountries=countryList.getListOfCountries();
//		for (Country country: listOfCountries) {
//			if(country.getId()==id)
//				return country;
//		}
//		
//		return null;
//	}

/// Utiliy method to create country list.
	public CountryList createCountryList()
	{
		Country usCountry=new Country(1, "US", "A");
		Country chinaCountry=new Country(2, "China", "B");
		Country nepalCountry=new Country(3, "Nepal", "C");
		Country bhutanCountry=new Country(4, "Bhutan", "D");

		List<Country> listOfCountries = new ArrayList<Country>();
		listOfCountries.add(usCountry);
		listOfCountries.add(chinaCountry);
		listOfCountries.add(nepalCountry);
		listOfCountries.add(bhutanCountry);
		return new CountryList(listOfCountries);
	}
	
	/*
	 * @RequestMapping(value="/countries/{name}", method=RequestMethod.GET) public
	 * ResponseEntity<Void> updateStudent(@PathVariable("name") String
	 * countryName, @RequestBody Country country) {
	 * 
	 * System.out.println("Country Name:" +countryName);
	 * System.out.println("Country Name:" +country.getCountryName()+"Country Id:"
	 * +country.getId());
	 * 
	 * return new ResponseEntity<Void>(HttpStatus.OK);
	 * 
	 * }
	 */
	@RequestMapping("/countries/{name}")
	public String callingApi(HttpServletRequest request)
	{
		String name = request.getParameter("countryName");
		String rType = request.getParameter("requestType");
		
		System.out.println("name is:" + name + "request Type is:" + rType);
		return "Calling XML from Input";
		
	}
	
	@RequestMapping(value = "/country/{id}", method = RequestMethod.PUT)
	public String updateCountryInfo(@PathVariable("id") Integer id, @RequestBody Country country) {
		/*
		 * List<Country> listOfCountries = new ArrayList<Country>(); CountryList
		 * countryList=createCountryList();
		 * listOfCountries=countryList.getListOfCountries();
		 * 
		 * Country updateCountry=new Country(country.getId(), country.getCountryName(),
		 * country.getRequestType()); listOfCountries.add(updateCountry);
		 * listOfCountries.remove(0); System.out.println("Country Newly Added:");
		 * System.out.println("Country Name:" +country.getCountryName()+" "
		 * +"Country Id:" +country.getId()); return listOfCountries;
		 */
		System.out.println("Country Newly Added:" + country.getCountryName());
		System.out.println("Country ID:" +country.getId()+" " + "/n" +"Country requestType:" +country.getRequestType());
		//return "Request Type called";
		try {
			RequestWithType returnSomething = new RequestWithType(country);
			return returnSomething.fetchReq(country);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	@RequestMapping(value = "/fileContent", method = RequestMethod.GET)//,headers="Accept=application/xml")
	public void fileContent() throws ClassNotFoundException, IOException {
		try {
			String url = "jdbc:oracle:thin:@//fihecdpqdb232.emea.nsn-net.net:6210/SWD";
		    String username = "swd_01";
		    String password = "swdm19c22";
		    
		    String query
		        = "select * from swd_build where swd_build_id = "+ 99056;
		    Class.forName("oracle.jdbc.driver.OracleDriver");
		    Connection con = DriverManager.getConnection(url, username, password);
		    System.out.println(
		        "Connection Established successfully");
		    Statement st = con.createStatement();
		    ResultSet rs = st.executeQuery(query); 
		    //rs.next();
//		    String name;
//				name = rs.getString("FILE_NAME");
//				System.out.println(name);
	            if (rs.next()) {
	                // gets file name and file blob data
	                String fileName = rs.getString("FILE_NAME");
	                Blob blob = rs.getBlob("DOCUMENTATION");
	                InputStream inputStream = blob.getBinaryStream();
	                int fileLength = inputStream.available();
	                 System.out.println("File name::" +fileName);
	                System.out.println("fileLength = " + fileLength);

	            }
		        st.close(); 
		        con.close(); 
		        System.out.println("Connection Closed....");
				
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
   }
}
