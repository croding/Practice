package org.arpit.java2blog.controller;

import org.arpit.java2blog.bean.Country;

public interface selectRType {

	public void fetchReq(Country country);
}
