package com.nawaz;

public class EmployeeDAO {

}
