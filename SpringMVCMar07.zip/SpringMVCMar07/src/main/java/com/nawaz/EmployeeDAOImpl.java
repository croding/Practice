package com.nawaz;

public class EmployeeDAOImpl {

}
