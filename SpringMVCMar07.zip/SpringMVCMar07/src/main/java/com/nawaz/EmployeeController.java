package com.nawaz;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

public class EmployeeController {

	
	public ModelAndView addEmployee(@ModelAttribute("employee") Employee employee) {
		
		
		
	}
	
}
