package com.nawaz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbtSpringBootRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbtSpringBootRestApiApplication.class, args);
	}

}
