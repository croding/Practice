package com.nawaz.service;

import java.util.List;

import com.nawaz.entity.Student;

public interface StudentService {
	
	public Student createStudent(Student student);
	
	public List<Student> getAllStudent();

}
