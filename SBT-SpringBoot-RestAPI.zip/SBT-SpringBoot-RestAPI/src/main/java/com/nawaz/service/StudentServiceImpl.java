package com.nawaz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nawaz.entity.Student;
import com.nawaz.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepository studentRepo;

	@Override
	public Student createStudent(Student student) {
		
		return studentRepo.save(student);
	}

	@Override
	public List<Student> getAllStudent() {
		
		return studentRepo.findAll();
	}
	
	

}
