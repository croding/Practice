package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class Servlet1 extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		Cookie ck1 = new Cookie("cookie1", email);
		Cookie ck2 = new Cookie("cookie2", password);
		resp.addCookie(ck1);
		resp.addCookie(ck2);
		
		resp.sendRedirect("profile");
		out.println("<h1>User Email is"+email+"and password is "+password+"</h1>");
	}
	
	

}
