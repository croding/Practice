package com.nawaz.loadingfrompropertiesfile;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;

public class Student {
	@Value("${Student.name}")
	private String name;
	@Value("${Student.interesetedCourse}")
	private String interesetedCourse;
	@Value("${Student.hobby}")
	private String hobby;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public String getInteresetedCourse() {
		return interesetedCourse;
	}
	//@Required//student object gets created only if intereseted value is created
	public void setInteresetedCourse(String interesetedCourse) {
		this.interesetedCourse = interesetedCourse;
	}
	public String getHobby() {
		return hobby;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	
	public void displayStudentInfo() {
		System.out.println("Student Name is : " +name);
		System.out.println("Intereseted Course is : " +interesetedCourse);
		System.out.println("Student Hobby is : " +hobby);
	}
	
}
